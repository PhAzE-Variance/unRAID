**SABnzbd**

SABnzbd is an Open Source Binary Newsreader written in Python.