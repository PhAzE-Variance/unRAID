**GoDaddy DDNS**

GoDaddy DDNS is a python based script used to update GoDaddy A records for a given account, with the latest external IP detected on the current network. This allows the A record to remain up to date if a change in IP occurs.