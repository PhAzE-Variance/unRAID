#!/usr/bin/env python2.7

import imp
import logging
import sys
import pif
from godaddypy import Client, Account

# Setup logging
logging.basicConfig(filename='Godaddy_ddns.log',
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logging.info('*** BEGIN *** Starting GoDaddy DDNS update script')

# Get variables
logging.info('Collecting variables from Godaddy_ddns.cfg')
f = open('/boot/config/plugins/Godaddy_ddns/Godaddy_ddns.cfg')
global data
data = imp.load_source('data', '', f)
f.close()

# If data is empty, error and exit
if not data:
    logging.error('*** END *** Failed to collect variables from Godaddy_ddns.cfg')
    sys.exit(1)

# Get public IP
logging.info('Getting current public IP address')
public_ip = None
try:
    public_ip = pif.get_public_ip()
except Exception as e:
    get_ip_error = e

# If public IP is empty, error and exit
if not public_ip:
    logging.error('*** END *** Failed to get the current public IP address')
    logging.error('%s' % get_ip_error)
    sys.exit(1)
else:
    logging.info('Current public IP address is: %s' % public_ip)

# Get current A record
logging.info('Getting current A record for domain: %s' % data.DOMAIN)
my_acct = Account(api_key=data.APIKEY, api_secret=data.SECRET)
client = Client(my_acct)
current_a_record = None
try:
    current_a_record = client.get_a_records(data.DOMAIN)
except Exception as e:
    get_record_error = e

# If getting A record fails, error and exit
if not current_a_record:
    logging.error('*** END *** Failed to get A record from GoDaddy for domain: %s' % data.DOMAIN)
    logging.error('%s' % get_record_error)
    sys.exit(1)
else:
    logging.info('Current A record: %s' % current_a_record)

# Check if current public IP matches the A record, and update A record if not
current_ip = current_a_record[0]['data']
if current_ip != public_ip:
    logging.info('A record and public IP are not a match, updating A record to %s' % public_ip)
    try:
        client.update_ip(public_ip, domains=[data.DOMAIN])
    except Exception as e:
        update_record_error = e
        logging.error('*** END *** Failed to update A record, GoDaddy may have changed their API code')        
        logging.error('%s' % update_record_error)
        sys.exit(1)

    # If getting A record again fails, error and exit
    new_a_record = None
    try:
        new_a_record = client.get_a_records(data.DOMAIN)
    except Exception as e:
        new_record_error = e

    if not new_a_record:
        logging.error('*** END *** Failed to get A record from GoDaddy, unable to verify if update worked')
        logging.error('%s' % new_record_error)
        sys.exit(1)
    else:
        logging.info('New A record: %s' % new_a_record)

    # Check if the updated IP matches the current public IP
    new_ip = new_a_record[0]['data']
    if new_ip == public_ip:
        logging.info('*** END *** SUCCESS! A record was updated to %s' % public_ip)
    else:
        logging.error('Failed to update A record, GoDaddy may have changed their API code')
        sys.exit(1)
else:
    logging.info('*** END *** No update: A record and public IP currently match %s' % public_ip)

