**NZBGet**

NZBGet is a binary newsreader written in C++ and designed with performance in mind to achieve maximum download speed by using very little system resources.
