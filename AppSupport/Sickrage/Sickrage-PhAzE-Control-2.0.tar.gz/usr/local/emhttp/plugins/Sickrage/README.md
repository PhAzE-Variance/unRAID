**SickRage**

SickRage is an Open Source Python application.  Automatic Video Library Manager for TV Shows. It watches for new episodes of your favorite shows, and when they are posted it does its magic.