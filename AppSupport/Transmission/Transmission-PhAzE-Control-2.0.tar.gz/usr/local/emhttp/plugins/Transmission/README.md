**Transmission**

Transmission is an open source BitTorrent client designed for ease of use with full client functionality right out of the box.