**CouchPotato**

CouchPotato is an Open Source Python application used to download movies automatically, easily and in the best quality as soon as they are available.