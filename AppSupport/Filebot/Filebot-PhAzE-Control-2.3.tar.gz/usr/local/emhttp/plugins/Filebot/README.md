**FileBot**

FileBot is the ultimate tool for organizing and renaming your movies, tv shows or anime, and music as well as downloading subtitles and artwork.