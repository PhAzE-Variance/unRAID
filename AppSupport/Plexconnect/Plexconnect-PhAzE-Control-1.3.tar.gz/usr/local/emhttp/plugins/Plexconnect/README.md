**PlexConnect**

Plexconnect is a python based application used to fool Apple TV devices into connecting to Plex Media Server rather than connecting to the native trailers application. It's a way to bypass the restriction Apple has on allowing Plex on their aTV devices.