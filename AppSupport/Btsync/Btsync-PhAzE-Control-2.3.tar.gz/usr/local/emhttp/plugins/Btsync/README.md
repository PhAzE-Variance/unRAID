**BitTorrent Sync**

BitTorrent Sync uses advanced peer-to-peer technology to share files between devices.