<?PHP
# Setup page variables
$appname="Btsync";
$displayname="BitTorrent Sync";
$appexecutable="btsync";
$appconfigfile="config.conf";
$plglogfile="/var/log/PhAzE-Logs/{$appname}.log";
$arrayState=trim(shell_exec( "grep fsState /var/local/emhttp/var.ini | sed -n 's!fsState=\"\(.*\)\"!\\1!p'" ));
$ver60check=trim(shell_exec( "grep version /etc/unraid-version | sed -n 's!version=\"\(.*\)\"!\\1!p'" ));
$appRepoURL="https://www.getsync.com/platforms/desktop";

# Sets the loader background to match the theme based on unRaid version sicne 6 has a dark theme
$machine_type = trim(shell_exec( "uname -m" ));
if ($machine_type == "x86_64") {
	$loaderbgcolor = "html";
	$prefix = "";
	if (substr($ver60check, 0, 3) === "6.0") {
		$prefix = "/usr/local/emhttp";
	}
} else {
	$loaderbgcolor = ".Container";
	$prefix = "/usr/local/emhttp";
}
?>

<!-- ========================================================================= -->
<!-- Page load animation and text -->
<!-- ========================================================================= -->

<!-- # Add jquery library, show loader, fade out when loaded -->
<?if ($machine_type != "x86_64"):?>
	<script type='text/javascript' src='/plugins/<?=$appname;?>/scripts/jquery.min.js'></script>
<?endif;?>
<div id="loading">
	<img id="loading-image" src='/plugins/<?=$appname;?>/icons/loader.gif' alt="Loading..." />
	<p id="loading-text">LOADING PLUGIN</p>
</div>
<script language="javascript" type="text/javascript">
	$("#loading").css("background-color",$("<?=$loaderbgcolor;?>").css("background-color"));
	$("#loading").show();
</script>
<script language="javascript" type="text/javascript">
	$(window).load(function() {$("#loading").fadeOut("slow");});
</script>

<!-- ========================================================================= -->
<!-- Load current config file and check if program is installed already -->
<!-- ========================================================================= -->

<?PHP
# Check for cache drive and make sure its an actual disk drive
$cacheCheck = trim(shell_exec( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} checkcache" ));
if ($cacheCheck == "true")
	$commonDIR = "/mnt/cache/.PhAzE-Common";
else
	$commonDIR = "/usr/local/PhAzE-Common";

# This will clean any ^M characters caused by windows from the config file before use
if (file_exists("/boot/config/plugins/{$appname}/{$appname}.cfg"))
	shell_exec("sed -i 's!\r!!g' \"/boot/config/plugins/{$appname}/{$appname}.cfg\"");
if (file_exists("/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname}"))
	shell_exec("sed -i 's!\r!!g' \"/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname}\"");

# Check existence of files and make startfile if missing
$app_cfg = parse_ini_file( "/boot/config/plugins/{$appname}/{$appname}.cfg" );
$app_installed = file_exists( $app_cfg["INSTALLDIR"] . "/{$appexecutable}" ) ? "yes" : "no";
$app_rollback = file_exists( "boot/config/plugins/{$appname}.plg.old" ) ? "yes" : "no";
$app_startfile = file_exists( "{$commonDIR}/{$appname}/startcfg.sh" ) ? "yes" : "no";
if ($arrayState == "Started" && $app_installed == "yes" && $app_startfile == "no") {
	echo "<script>document.getElementById('loading-text').innerHTML = \"CHECKING DEPENDENCIES\";</script>";
	trim(shell_exec( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} writeexport" ));
}

# =========================================================================
## Collect local variables from config files and verify data as best as possible
# =========================================================================

# Check for forcecheck, this overrides the checkonline option
if ($machine_type == "x86_64") {
	if (isset($_POST["forcecheck"])) {
		$forcecheck = $_POST["forcecheck"];
	} else {
		$forcecheck = "no";
	}
} else {
	if (isset($GLOBALS["forcecheck"])) {
		$forcecheck = $GLOBALS["forcecheck"];
	} else {
		$forcecheck = "no";
	}
}

# See if plugin is allowed to check online for latest updates on GUI load
if (isset($app_cfg['CHECKONLINE']) && ($app_cfg['CHECKONLINE'] == "yes" || $app_cfg['CHECKONLINE'] == "no")) {
	$app_checkonline=$app_cfg["CHECKONLINE"];
} else {
	$app_checkonline="yes";
}

# Check if there is internet conneciton so page doesn't stall out, only check if CHECKONLINE is allowed
if ($app_checkonline == "yes" || $forcecheck == "yes") {
	$connected = @fsockopen("www.google.com", 80, $errno, $errstr, 5);
	if ($connected){
		$is_conn = "true";
		fclose($connected);
	} else {
		$is_conn = "false";
	}
} else {
	$is_conn = "false";
}

# Set readonly status if array is offline
if ($arrayState == "Started") {
	$app_readonly = "";
	$app_disabled = "";
} else {
	$app_readonly = 'readonly="readonly"';
	$app_disabled = 'disabled="disabled"';
}

# Plugin Current Version Variable
if (file_exists("/boot/config/plugins/{$appname}.plg")) {
	$app_plgver = trim(shell_exec ( "grep 'ENTITY plgVersion' /boot/config/plugins/{$appname}.plg | sed -n 's!.*\t\"\(.*\)\".*!\\1!p'" ));
	if ($app_plgver == "") {
		$app_plgver = "Unknown plugin version";
	}
} else {
	$app_plgver = "(Plugin File Missing)";
}

# Get latest release of the plugin
if ($is_conn == "true") {
	echo "<script>document.getElementById('loading-text').innerHTML = \"CHECKING LATEST PLUGIN VERSION\";</script>";
	$REPO2="https://github.com/PhAzE-Variance/unRAID/raw/master/Versions";
	$app_newversionPLG = trim(shell_exec ( "wget -qO- --no-check-certificate $REPO2 | sed -n 's/BTSync: \(.*\)/\\1/p'" ));
} else {
	$app_newversionPLG = "";
}

# Service Status Variable
if (isset($app_cfg['SERVICE']) && ($app_cfg['SERVICE'] == "enable" || $app_cfg['SERVICE'] == "disable"))
	$app_service = $app_cfg['SERVICE'];
else
	$app_service = "disable";

# Install Directory Variable
if (isset($app_cfg['INSTALLDIR']))
	$app_installdir = $app_cfg['INSTALLDIR'];
else
	$app_installdir = "/usr/local/{$appname}";

# Config Directory Variable
if (isset($app_cfg['CONFIGDIR'])) {
	$app_configdir = $app_cfg['CONFIGDIR'];
} else {
	$app_configdir = "{$app_installdir}/config";
}

# Use SSL Variable
if ($arrayState=="Started" && file_exists("{$app_configdir}/{$appconfigfile}") && shell_exec("grep -m 1 'force_https' {$app_configdir}/{$appconfigfile}")) {
	$app_usessl = trim(shell_exec( "sed -n 's!.*\"force_https\" : \([A-Za-z]*\).*!\\1!p' {$app_configdir}/{$appconfigfile}" ));
	if (strtolower($app_usessl) == "true")
		$app_usessl = "yes";
	else
		$app_usessl = "no";
} else if (isset($app_cfg['USESSL']) && ($app_cfg['USESSL'] == "yes" || $app_cfg['USESSL'] == "no")) {
	$app_usessl = $app_cfg['USESSL'];
} else {
	$app_usessl = "no";
}

# Use SSL Certs Variable
if (isset($app_cfg['USECERTS'])) {
	$app_usecerts = $app_cfg['USECERTS'];
} else {
	$app_usecerts = "no";
}

# SSL Certificate Variable
if ($arrayState=="Started" && file_exists("{$app_configdir}/{$appconfigfile}") && shell_exec("grep '\"ssl_certificate\"' {$app_configdir}/{$appconfigfile}")) {
	$app_sslcert = trim(shell_exec( "sed -n 's!.*\"ssl_certificate\" : \"\(.*\)\".*!\\1!p' {$app_configdir}/{$appconfigfile}" ));
} else if (isset($app_cfg['SSLCERT'])) {
	$app_sslcert = $app_cfg['SSLCERT'];
} else {
	$app_sslcert = "";
}

# SSL Private Key Variable
if ($arrayState=="Started" && file_exists("{$app_configdir}/{$appconfigfile}") && shell_exec("grep '\"ssl_private_key\"' {$app_configdir}/{$appconfigfile}")) {
	$app_sslpriv = trim(shell_exec( "sed -n 's!.*\"ssl_private_key\" : \"\(.*\)\".*!\\1!p' {$app_configdir}/{$appconfigfile}" ));
} else if (isset($app_cfg['SSLPRIV'])) {
	$app_sslpriv = $app_cfg['SSLPRIV'];
} else {
	$app_sslpriv = "";
}

# Port Number Variable
if ($arrayState=="Started" && file_exists("{$app_configdir}/{$appconfigfile}") && shell_exec("grep -m 1 '\"listen\"' {$app_configdir}/{$appconfigfile}")) {
	$app_port = trim(shell_exec( "grep -m 1 '\"listen\"' {$app_configdir}/{$appconfigfile} | sed -n 's!.*: \".*:\(.*\)\".*!\\1!p'" ));
	if (is_numeric($app_port)) {
		if ($app_port < 0 || $app_port > 65535)
			$app_port = "8888";
	} else {
		$app_port = "8888";
	}
} else if (isset($app_cfg['PORT']) && is_numeric($app_cfg['PORT'])) {
	$app_port = $app_cfg['PORT'];
	if ($app_port < 0 || $app_port > 65535)
		$app_port = "8888";
} else {
	$app_port = "8888";
}

# URL Base Variable
#if ($arrayState=="Started" && file_exists("{$app_configdir}/{$appconfigfile}") && shell_exec("grep -m 1 '^url_base =' {$app_configdir}/{$appconfigfile}")) {
#	$app_urlbase = trim(shell_exec( "sed -n 's!url_base = \(.*\)!\\1!p' {$app_configdir}/{$appconfigfile}"));
#} else if (isset($app_cfg['URLBASE'])) {
#	$app_urlbase = $app_cfg['URLBASE'];
#} else {
#	$app_urlbase = "";
#}
$app_urlbase = "gui";

# Run As User Variable
if (isset($app_cfg['RUNAS']))
	$app_runas = $app_cfg['RUNAS'];
else
	$app_runas = "nobody";

# Storage Check Status Variable
if (isset($app_cfg['PLG_STORAGESIZE']) && ($app_cfg['PLG_STORAGESIZE'] == "yes" || $app_cfg['PLG_STORAGESIZE'] == "no"))
	$app_storagesizestat = $app_cfg['PLG_STORAGESIZE'];
else
	$app_storagesizestat = "yes";

# Data Check Status Variable
if (isset($app_cfg['PLG_DATACHECK']) && ($app_cfg['PLG_DATACHECK'] == "yes" || $app_cfg['PLG_DATACHECK'] == "no"))
	$app_datacheckstat = $app_cfg['PLG_DATACHECK'];
else
	$app_datacheckstat = "yes";

# =========================================================================
## Check is program is installed and running to get extra information
# =========================================================================

# Get current installed version of the program
if ($arrayState=="Started") {
	$app_curversion = trim(shell_exec ( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} currentversion" ));
	if ($app_curversion == "")
		$app_curversion = "UNKNOWN";
}

if ($app_installed=="yes" && $arrayState=="Started") {
	$app_running = trim(shell_exec( "[ -f /proc/`cat /var/run/{$appname}/{$appname}.pid 2> /dev/null`/exe ] && echo 'yes' || echo 'no' 2> /dev/null" ));
	if ($app_running == "yes")
		$app_updatestatus = "Running";
	else
		$app_updatestatus = "Stopped";

	# Get latest release version of the program
	if ($is_conn == "true") {
		echo "<script>document.getElementById('loading-text').innerHTML = \"CHECKING LATEST APP VERSION\";</script>";
		$app_newversion = trim(shell_exec ( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} latestversion" ));
	} else {
		$app_newversion = "";
	}

	# Add storage size and data check if settings are set to yes
	if ($app_storagesizestat == "yes")
		$app_storagesize = shell_exec ( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} storagesize" );
	if ($app_datacheckstat == "yes")
		$app_datacheck = shell_exec ( "/usr/local/emhttp/plugins/{$appname}/scripts/rc.{$appname} datacheck" );

	# Check if the app can be updated
	if ($app_newversion != "" && $app_newversion != $app_curversion)
		$app_canupdate = "yes";
	else
		$app_canupdate = "no";

	# Get dependency version numbers
	# This app has no dependency files
}

# Get plugin version current and new
if ($app_newversionPLG != "" && $app_newversionPLG != $app_plgver )
	$app_canupdatePLG = "yes";
else
	$app_canupdatePLG = "no";

echo "<script>document.getElementById('loading-text').innerHTML = \"DONE\";</script>";
?>

<!-- ========================================================================= -->
<!-- Create the HTML code used to display the settings GUI -->
<!-- ========================================================================= -->

<div id="PANELALL"><div id="PANELLEFT">
	<div class="TITLEBARLEFT title" id="title">
		<span class="left"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/device_status.png">&#32;Status:
			<?if ($app_installed=="yes" && $arrayState=="Started"):?>
				<?if ($app_running=="yes"):?>
					<span class="green"><b>RUNNING</b></span>
					<span class="right">
						<?if ($app_usessl=="yes"):?>
							<a id="UPDATEBUTTON" class="UIBUTTON" href="https://<?=$var['NAME'];?>:<?=$app_port;?>/<?=$app_urlbase;?>" target="_blank">Web UI</a>
						<?else:?>
							<a id="UPDATEBUTTON" class="UIBUTTON" href="http://<?=$var['NAME'];?>:<?=$app_port;?>/<?=$app_urlbase;?>" target="_blank">Web UI</a>
						<?endif;?>
					</span>
				<?else:?>
					<span class="red"><b>STOPPED</b></span>
				<?endif;?>
			<?else:?>
				<span class="red"><b>NOT READY</b></span>
			<?endif;?>  
		</span>
	</div>
	<div id="DIVLEFT">
		<div id="T50LM">
			<?if ($arrayState == "Started"):?>
				<p id="PLINE">Array State:<b><span class="green">ONLINE</span></b></p>
				<?if ($app_curversion == "NOT INSTALLED" || $app_curversion == "UNKNOWN"):?>
					<p id="PLINE">Installed Version:<b><span class="red"><?=$app_curversion;?></span></b></p>
				<?else:?>
					<p id="PLINE" class="longver">Installed Version:<b><span class="green" title="<?=$app_curversion;?>"><?=$app_curversion;?></span></b></p>
				<?endif;?>
			<?else:?>
				<p id="PLINE">Array State:<b><span class="red">OFFLINE</span></b></p>
			<?endif;?>
		</div>
		<?if ($app_installed=="yes"):?>
			<?if ($app_running=="yes"):?>
				<div id="T25RM">
					<form name="app_stop" method="POST" action="/update.htm" target="progressFrame">
						<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
						<input type="hidden" name="arg1" value="stop"/>
						<input <?=$app_disabled;?> type="submit" name="runCmd" id="STDSMBUTTONR" value="Stop"/>
					</form>
				</div>
				<div id="T25LM">
					<form name="app_restart" method="POST" action="/update.htm" target="progressFrame">
						<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
						<input type="hidden" name="arg1" value="restart"/>
						<input <?=$app_disabled;?> type="submit" name="runCmd" id="STDSMBUTTONL" value="Restart"/>
					</form>
				</div>
			<?else:?>
				<div id="T50CM">
					<form name="app_start" method="POST" action="/update.htm" target="progressFrame">
						<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
						<input type="hidden" name="arg1" value="buttonstart"/>
						<input <?=$app_disabled;?> type="submit" name="runCmd" id="STDSMBUTTON" value="Start"/>
					</form>
				</div>
			<?endif;?>
		<?else:?>
			<div id="T50CM">
				<form name="app_install" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
					<input type="hidden" name="arg1" value="install"/>
					<input <?=$app_disabled;?> type="submit" name="runCmd" id="STDSMBUTTON" value="Install"/>
				</form>
			</div>
		<?endif;?>
	</div>
	<? if ($app_installed=="yes" && $arrayState=="Started"): ?>
		<?if ($app_canupdate=="yes"):?>
			<div id="DIVLEFT">
				<div id="T50LM">
					<p id="PLINE"></p>
				</div>
				<div id="T50CM">
					<form name="app_updateapp" method="POST" action="/update.htm" target="progressFrame">
						<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
						<input type="hidden" name="arg1" value="update"/>
						<input type="hidden" name="arg3" value="<?=$app_updatestatus;?>"/>
						<input id="UPDATEBUTTON" type="submit" name="runCmd" value="Update <?=$displayname;?>"/>
					</form>
					<p id="VERSION" class="longver" title="<?=$app_newversion;?>"><b>New Version: <?=$app_newversion;?></b></p>
				</div>
			</div>
		<?endif;?>
		<div class="TITLEBARLEFT title" id="title">
			<span class="left"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/depends.png">&#32;Dependencies:</span>
		</div>
		<div id="DIVLEFT">
			<div id="T50LT">
				<p id="PLINE"><?=$displayname;?> does not require any dependencies</p>
			</div>
		</div>
	<? endif; ?>
	<div class="TITLEBARLEFT title" id="title">
		<span class="left"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/information.png">&#32;Information:</span>
	</div>
	<? if ($is_conn == "false" && ($app_checkonline == "yes" || $forcecheck == "yes")):?>
		<div id="DIVLEFT">
			<div id="T100LT">
				<p id="PLINE"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/warning.png"/><span class="red" id="ERRORPAD"> <b>No Internet Connection Detected</b></span></p>
			</div>
		</div>
	<? endif;?>
	<? if ($arrayState != "Started"):?>
		<div id="DIVLEFT">
			<div id="T100LT">
				<p id="PLINE"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/warning.png"/><span class="red" id="ERRORPAD"> <b>Some settings cannot be changed while the array is stopped</b></span></p>
			</div>
		</div>
	<? endif;?>
	<? if ($app_installed=="yes" && $arrayState=="Started"): ?>
		<? if ($app_storagesizestat=="yes" || $app_datacheckstat=="yes"): ?>
			<div id="DIVLEFT">
				<? if ($app_storagesizestat == "yes"): ?>
					<div id="T50LT">
						<?=$app_storagesize;?>
					</div>
				<? endif; ?>
				<? if ($app_datacheckstat == "yes"): ?>
					<div id="T50LT">
						<?=$app_datacheck;?>
					</div>
				<? endif; ?>
			</div>
		<? endif; ?>
	<? endif; ?>
	<div id="DIVLEFT">
		<div id="T50LM">
			<p id="PLINE"><b>Plugin Version: <?=$app_plgver;?></b></p>
		</div>
		<? if ($app_rollback=="yes"):?>
			<div id="T25RM">
				<form name="app_downgrade" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
					<input type="hidden" name="arg1" value="downgradeplg"/>
					<input type="submit" name="runCmd" id="STDLGBUTTONR" value="Downgrade Plugin"
						onclick="return confirm('Pressing OK will install the previous backup of this plugin.')"/>
				</form>
			</div>
			<div id="T25LM">
				<form name="app_uninstall" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
					<input type="hidden" name="arg1" value="removeplg"/>
					<input type="submit" name="runCmd" id="STDLGBUTTONL" value="Uninstall Plugin" 
						onclick="return confirm('Pressing OK will remove this plugin, including all support and install files. Application directories will not be removed. \n\nIf the array is offline during uninstall, some dependencies may remain on the cache drive.')"/>
				</form>
			</div>
		<?else:?>
			<div id="T50CM">
				<form name="app_uninstall" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
					<input type="hidden" name="arg1" value="removeplg"/>
					<input type="submit" name="runCmd" id="STDLGBUTTON" value="Uninstall Plugin" 
						onclick="return confirm('Pressing OK will remove this plugin, including all support and install files. Application directories will not be removed. \n\nIf the array is offline during uninstall, some dependencies may remain on the cache drive.')"/>
				</form>
			</div>
		<?endif;?>
	</div>
	<div id="DIVLEFT">
		<div id="T50LT">
			<p id="PLINE"><a title="<?=$appname;?> Activity Log - <?=$plglogfile;?>" href="#" target="_blank" id="ACTIVITYLINK" onclick="openLog();return false;">View Activity Log</a></p>
		</div>
		<?if ($app_canupdatePLG=="yes"):?>
			<div id="T50CM">
				<form name="app_update1" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
					<input type="hidden" name="arg1" value="updateplg"/>
					<input id="UPDATEBUTTON" type="submit" name="runCmd" class="UPDATEBTN" value="Update Plugin"/>
				</form>
				<p id="VERSION"><b>New Version: <?=$app_newversionPLG;?></b></p>
			</div>
		<?endif;?>
		<? if ($app_checkonline=="no" && $forcecheck != "yes"):?>
			<div id="T50CM">
				<form method="POST" action="">
					<input type="hidden" id="forcecheck" name="forcecheck" value="yes"/>
					<input type="submit" id="UPDATEBUTTON" class="UPDATEBTN" value="Manual Update Check"/>
				</form>
			</div>
		<?endif;?>
	</div>
</div>
<div id="PANELRIGHT">
	<div class="TITLEBARRIGHT title" id="title">
		<span class="left"><img id="IMGICON" src="/plugins/<?=$appname;?>/icons/new_config.png">&#32;Configuration:</span>
	</div>
	<div id="DIVRIGHT">
		<form name="app_settings" method="POST" action="/update.htm" target="progressFrame">
			<input type="hidden" name="cmd" value="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/rc.<?=$appname;?>"/>
			<table class="settings" id="TABLESETTINGS">
				<tr>
					<td id="TDSETTINGS">Enable <?=$displayname;?>:</td>
					<td id="TDSETTINGS">
						<select name="arg1" size="1">
							<?=mk_option($app_service, "disable", "No");?>
							<?=mk_option($app_service, "enable", "Yes");?>
						</select>
					</td>
				</tr>
				<input type="hidden" name="arg2" value=""/>
				<tr>
					<td id="TDSETTINGS">Install directory:</td>
					<td id="TDSETTINGS"><input <?=$app_readonly;?> type="text" name="arg3" id="TEXTLARGE" maxlength="60" value="<?=$app_installdir;?>"/></td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Config directory:</td>
					<td id="TDSETTINGS"><input <?=$app_disabled;?> type="checkbox" name="use_data" <?=($app_configdir != "{$app_installdir}/config")?"checked=\"checked\"":"";?> onChange="checkDATADIR(this.form);"/> 
					<input <?=$app_readonly;?> type="text" name="arg4" id="TEXTSMALL" maxlength="60" value="<?=$app_configdir;?>"/></td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Use SSL:</td>
					<td id="TDSETTINGS"><input <?=$app_disabled;?> type="checkbox" name="use_ssl" <?=($app_usessl=="yes")?"checked=\"checked\"":"";?> onChange="checkSSLPORT(this.form);">
					<input <?=$app_readonly;?> type="hidden" name="arg5" value="<?=$app_usessl;?>"></td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Use custom certificates:</td>
					<td id="TDSETTINGS"><input <?=$app_disabled;?> type="checkbox" name="use_certs" <?=($app_usecerts=="yes")?"checked=\"checked\"":"";?> onChange="checkSSLCERTS(this.form);">
					<input <?=$app_readonly;?> type="hidden" name="arg6" value="<?=$app_usecerts;?>"></td>
				</tr>
				<tr id="cert_file">
					<td id="TDSETTINGS">Custom certificate file:<font size="1">&emsp;(Full path)</font></td>
					<td id="TDSETTINGS"><input <?=$app_readonly;?> type="text" name="arg7" id="TEXTLARGE" maxlength="60" value="<?=$app_sslcert;?>"></td>
				</tr>
				<tr id="priv_file">
					<td id="TDSETTINGS">Custom private key file:<font size="1">&emsp;(Full path)</font></td>
					<td id="TDSETTINGS"><input <?=$app_readonly;?> type="text" name="arg8" id="TEXTLARGE" maxlength="60" value="<?=$app_sslpriv;?>"></td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Port:</td>
					<td id="TDSETTINGS"><input <?=$app_readonly;?> type="text" name="arg9" id="TEXTLARGE" maxlength="5" value="<?=$app_port;?>"></td>
				</tr>
				<tr>
					<td id="TDSETTINGS">URL base: <font size="1">&emsp;(Read-Only)</font></td>
					<td id="TDSETTINGS"><input readonly type="text" name="arg10" id="TEXTLARGE" maxlength="60" value="<?=$app_urlbase;?>"></td>
				</tr>
				<tr><td id="TDSETTINGS" colspan="2"><div id="DIVIDER"> </div></td></tr>
				<tr>
					<td id="TDSETTINGS">Run as user:</td>
					<td id="TDSETTINGS">
						<select name="runas" size="1" onChange="checkUSER(this.form);">
							<?=mk_option($app_runas, "nobody", "nobody");?>
							<?=mk_option($app_runas, "root", "root");?>
							<option value="other" <?=($app_runas != "root" && $app_runas != "nobody") ? "selected=yes":"";?>>other</option>
						</select>
						<input type="hidden" name="arg11" id="TEXTUSER" maxlength="40" value="<?=$app_runas;?>"/>
					</td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Show storage memory usage:</td>
					<td id="TDSETTINGS">
						<select name="storagesize" size="1" onChange="checkSTORAGE(this.form);">
							<?=mk_option($app_storagesizestat, "yes", "Yes");?>
							<?=mk_option($app_storagesizestat, "no", "No");?>
						</select>
						<input type="hidden" name="arg12" value="<?=$app_storagesizestat;?>"/>
					</td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Show data persistency information:</td>
					<td id="TDSETTINGS">
						<select name="datacheck" size="1" onChange="checkDATAPERSIST(this.form);">
							<?=mk_option($app_datacheckstat, "yes", "Yes");?>
							<?=mk_option($app_datacheckstat, "no", "No");?>
						</select>
						<input type="hidden" name="arg13" value="<?=$app_datacheckstat;?>"/>
					</td>
				</tr>
				<tr>
					<td id="TDSETTINGS">Check for updates on page load:</td>
					<td id="TDSETTINGS">
						<select name="checkonline" size="1" onChange="checkONLINESTAT(this.form);">
							<?=mk_option($app_checkonline, "yes", "Yes");?>
							<?=mk_option($app_checkonline, "no", "No");?>
						</select>
						<input type="hidden" name="arg14" value="<?=$app_checkonline;?>"/>
					</td>
				</tr>
			</table><br>
			<div align="center">
				<input type="submit" name="runCmd" value="Apply" id="BOTTOMPAD" onClick="verifyDATA(this.form);"/>
				<input type="button" id="BOTTOMPAD" value="Done" onClick="done();">
			</div>
		</form>
	</div>
</div></div>
<div id="FOOTER2">
	Buy PhAzE a beer? <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=griptionize%40hotmail%2ecom&lc=CA&item_name=PhAzE%20Unraid%20Plugins%20%2d%20Donations&currency_code=CAD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted]PayPal" target="_blank"><img src="/plugins/<?=$appname;?>/icons/paypal.png"></a>
</div>

<!-- ========================================================================= -->
<!-- Javascript functions to verify data, and perform other GUI related tasks -->
<!-- ========================================================================= -->

<script type="text/javascript">

function openLog() {
	var machine_type = "<?=$machine_type;?>";
	var title="<?=$appname;?> Activity Log";
	if (machine_type == "x86_64") {
		<?if (substr($ver60check, 0, 3) === "6.0"):?>
			var url="/usr/bin/tail -n 42 -f <?=$plglogfile;?>";
			openWindow( url, title,600,900);
		<?else:?>
			var url="<?=$prefix;?>/plugins/<?=$appname;?>/scripts/tail_log&arg1=<?=$appname;?>.log";
			openWindow( url, title,600,900);
		<?endif;?>
	} else {
		var url="/logging.htm?title=" + title + "&cmd=/usr/bin/tail -n 42 -f <?=$plglogfile;?>&forkCmd=Start";
		openWindow( url, title.replace(/ /g, "_"),600,900);
	}
}
 
function checkDATADIR(form) {
	if (form.use_data.checked == false ) {
		form.arg4.value = form.arg3.value + "/config";
		form.arg4.type = "hidden";
	} else {
		form.arg4.value = "<?=$app_configdir;?>";
		form.arg4.type = "text";
	}
}

function checkSSLPORT(form) {
	if (form.use_ssl.checked == false ) {
		form.arg5.value = "no";
	} else {
		form.arg5.value = "yes";
	}
}

function checkSSLCERTS(form) {
	if (form.use_certs.checked == false ) {
		form.arg6.value = "no";
		form.arg7.type = "hidden";
		form.arg8.type = "hidden";
		document.getElementById("cert_file").style.display = "none";
		document.getElementById("priv_file").style.display = "none";
	} else {
		form.arg6.value = "yes";
		form.arg7.type = "text";
		form.arg8.type = "text";
		document.getElementById("cert_file").style.display = "";
		document.getElementById("priv_file").style.display = "";
	}
}

function checkUSER(form) {
	if (form.runas.selectedIndex < 2 ) {
		form.arg11.value = form.runas.options[form.runas.selectedIndex].value;
		form.arg11.type = "hidden";
	} else {
		form.arg11.value = "<?=$app_runas;?>";
		form.arg11.type = "text";
	}
}

function checkSTORAGE(form) {
	form.arg12.value = form.storagesize.options[form.storagesize.selectedIndex].value;
}

function checkDATAPERSIST(form) {
	form.arg13.value = form.datacheck.options[form.datacheck.selectedIndex].value;
}

function checkONLINESTAT(form) {
	form.arg14.value = form.checkonline.options[form.checkonline.selectedIndex].value;
}

function verifyDATA(form) {
	if (form.arg3.value == null || !(/\S/.test(form.arg3.value))){
		form.arg3.value = "/usr/local/<?=$appname?>";
	}
	if (form.arg4.value == null || !(/\S/.test(form.arg4.value)) || form.use_data.checked == false){
		form.arg4.value = form.arg3.value + "/config";
	}
	if (form.arg5.value != "yes" && form.arg5.value != "no") {
		form.arg5.value = "no";
	}
	if (form.arg6.value != "yes" && form.arg6.value != "no") {
		form.arg6.value = "no";
	}
	if (form.arg7.value == null || !(/\S/.test(form.arg7.value))){
		form.arg7.value = "!";
	}
	if (form.arg8.value == null || !(/\S/.test(form.arg8.value))){
		form.arg8.value = "!";
	}
	if (isNumber(form.arg9.value)){
		if (form.arg9.value < 0 || form.arg9.value > 65535){
			form.arg9.value = "8888";
		}
	} else {
		form.arg9.value = "8888";
	}
	if (!(/\S/.test(form.arg10.value))){
		form.arg10.value = "!";
	}
	if (form.arg11.value == ""){
		form.arg11.value = "nobody";
	}
	if (form.arg12.value != "yes" && form.arg12.value != "no"){
		form.arg12.value = "yes";
	}
	if (form.arg13.value != "yes" && form.arg13.value != "no"){
		form.arg13.value = "yes";
	}
	if (form.arg14.value != "yes" && form.arg14.value != "no"){
		form.arg14.value = "yes";
	}

	form.arg1.value = form.arg1.value.replace(/ /g,"_");
	form.arg2.value = form.arg2.value.replace(/ /g,"_");
	form.arg3.value = form.arg3.value.replace(/ /g,"_");
	form.arg4.value = form.arg4.value.replace(/ /g,"_");
	form.arg5.value = form.arg5.value.replace(/ /g,"_");
	form.arg6.value = form.arg6.value.replace(/ /g,"_");
	form.arg7.value = form.arg7.value.replace(/ /g,"_");
	form.arg8.value = form.arg8.value.replace(/ /g,"_");
	form.arg9.value = form.arg9.value.replace(/ /g,"_");
	form.arg10.value = form.arg10.value.replace(/ /g,"_");
	form.arg11.value = form.arg11.value.replace(/ /g,"_");
	form.arg12.value = form.arg12.value.replace(/ /g,"_");
	form.arg13.value = form.arg13.value.replace(/ /g,"_");
	form.arg14.value = form.arg14.value.replace(/ /g,"_");

	form.arg2.value = form.arg3.value
		+ " " + form.arg4.value
		+ " " + form.arg5.value
		+ " " + form.arg6.value
		+ " " + form.arg7.value
		+ " " + form.arg8.value
		+ " " + form.arg9.value
		+ " " + form.arg10.value
		+ " " + form.arg11.value
		+ " " + form.arg12.value
		+ " " + form.arg13.value
		+ " " + form.arg14.value;
	form.arg2.value = form.arg2.value.replace(/@20/g,"@@2200");
	form.arg2.value = form.arg2.value.replace(/ /g,"@20");
	return true;
}

function isNumber(n) {
	return !isNaN(parseFloat(n)) && isFinite(n);
}

checkUSER(document.app_settings);
checkSSLPORT(document.app_settings);
checkSSLCERTS(document.app_settings);
checkDATADIR(document.app_settings);
checkSTORAGE(document.app_settings);
checkDATAPERSIST(document.app_settings);
checkONLINESTAT(document.app_settings);
</script>
