**Maraschino**

Maraschino is an Open Source Python application used as a frontend web interface for XBMC HTPCs.