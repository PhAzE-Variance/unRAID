**Plex Media Server**

Plex Media Server simplifies your life by organizing all of your personal media, making it beautiful and streaming it to all of your devices.