**Sick Beard Alt**

Sick Beard is an Open Source Python application.  The ultimate PVR application that searches for and manages your TV shows. This plugin allows for a second instance of this application to be run at the same time.