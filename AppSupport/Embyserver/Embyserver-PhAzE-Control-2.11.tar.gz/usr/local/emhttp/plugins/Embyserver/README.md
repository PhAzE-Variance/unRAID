**Emby Server**

Emby Server organizes your content into a beautiful display that is both fun and easy to use. It never takes more than a few taps to find the latest movie or show you want to watch.